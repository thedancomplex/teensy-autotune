Plugin Installation
-------------------

Copy the plugin .lv2 folder to $HOME/.lv2/

  mkdir -p $HOME/.lv2
	cp -a *.lv2  $HOME/.lv2/


Or alternatively copy it to a system-wide directory, see:
http://lv2plug.in/pages/filesystem-hierarchy-standard.html
